import time
import threading
from logic.events import emitter
 
_started = False
 
def exit_virt(bot):
    # Ждём 5 секунд после спавна
    time.sleep(5)
 
    # Отправляем команду выхода из квеста
    for cmd in ["/stopq", "/qstop"]:
        try:
            bot.sendchat(cmd)
            print(f"[VIRT] Отправил: {cmd}")
        except Exception as e:
            print(f"[ERR sendchat] {e}")
        time.sleep(2)
 
@emitter.on("onSpawn")
def on_spawn(bot):
    global _started
    if _started:
        return
    _started = True
    print("[VIRT] Бот заспавнился, запускаю выход из вирта")
    threading.Thread(target=exit_virt, args=(bot,), daemon=True).start()
 
@emitter.on("onShowDialog")
def on_show_dialog(bot, dialog_id, dialog_style, title, info, button1, button2):
    print(f"[DIALOG] id={dialog_id} title={title} info={info} b1={button1} b2={button2}")
    txt = ((title or "") + " " + (info or "")).lower()
    if "закончить обучение" in txt or "действительно" in txt or "выйти" in txt:
        try:
            bot.SendDialogResponse(0)
            print("[VIRT] Нажал кнопку 0 в диалоге")
        except Exception as e:
            print(f"[ERR dialog] {e}")