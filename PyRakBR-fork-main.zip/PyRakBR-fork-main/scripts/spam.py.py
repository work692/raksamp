import time
import random
import threading
from logic.events import emitter

CHANNEL = "@Arcanum_br"
INTERVAL = 10

TEMPLATES = [
    "ого а кто видел что творится в тгк {ch}?",
    "а кто еще не получил бесплатно вирты в тгк {ch}?",
    "кто еще не забрал бесплатные вирты в тгк {ch}?",
    "вы уже видели новый слив в тгк {ch}?",
    "а вы уже заходили в тгк {ch}? там такое выложили",
    "в тгк {ch} опять раздают вирты, успевайте",
    "народ, в тгк {ch} новая обнова, кто уже скачал?",
    "а кто знает что сейчас творится в тгк {ch}?",
    "ребята, в тгк {ch} щас бесплатные вирты раздают",
    "кто еще не подписался на тгк {ch}? там вирты бесплатно",
    "в тгк {ch} вышла свежая обнова, го качать",
    "а вы в курсе что в тгк {ch} дают вирты бесплатно?",
    "ничего себе че в тгк {ch} выложили, кто видел?",
    "кто еще не в курсе про тгк {ch}? там слив за сливом",
    "заходите в тгк {ch}, там сейчас раздача виртов",
    "а кто уже забрал халявные вирты в тгк {ch}?",
    "в тгк {ch} такой слив обновы, кто видел?",
    "спасибо тгк {ch} за такой слив обновы!",
    "кто еще не качал обнову в тгк {ch}?",
    "в тгк {ch} топовая обнова, не пропустите",
    "а кто не успел на раздачу виртов в тгк {ch}?",
    "реально кто-то еще не сидит в тгк {ch}?",
    "вы только гляньте что выложили в тгк {ch}!",
    "тгк {ch} снова всех удивил, кто видел?",
    "в тгк {ch} бесплатные вирты и свежий слив, заходите",
    "кто хочет бесплатно вирты? залетайте в тгк {ch}",
    "а кто еще не видел обнову в тгк {ch}?",
    "в тгк {ch} щас движ, кто еще не там?",
    "господа, а вы уже были в тгк {ch}?",
    "сегодня в тгк {ch} вообще огонь, кто успел глянуть?",
]

_started = False
_queue = []
_last = None
_lock = threading.Lock()


def generate_text():
    global _queue, _last
    with _lock:
        if not _queue:
            _queue = TEMPLATES[:]
            random.shuffle(_queue)
            # чтобы на стыке кругов не было одинаковых подряд
            if _last is not None and _queue[-1] == _last:
                _queue[0], _queue[-1] = _queue[-1], _queue[0]
        template = _queue.pop()
        _last = template
        return template.format(ch=CHANNEL)


def spam_loop(bot):
    while True:
        text = generate_text()
        try:
            bot.sendchat(text)
            print(f"[SENT] {text}")
        except Exception as e:
            print(f"[ERROR] {e}")
        time.sleep(INTERVAL)


@emitter.on("onShowChat")
def on_chat(bot, message):
    global _started
    if _started:
        return
    _started = True
    print("[SPAM] Запускаю рассылку")
    threading.Thread(target=spam_loop, args=(bot,), daemon=True).start()